clear all
set more off

* Set the project root to the current Stata working directory.

global ROOT "`c(pwd)'"

global RAW     "$ROOT/00_raw_data"
global CODE    "$ROOT/01_code"
global WORK    "$ROOT/02_work_data"
global RESULT  "$ROOT/03_results"
global PAPER   "$ROOT/04_paper"

global RAW_COMPANY "$RAW/01_company_info"
global RAW_CONTROL "$RAW/02_controls"
global RAW_FIN     "$RAW/03_financial_data"
global RAW_DTI     "$RAW/04_digital_transformation"

global FIN_INDEX "$RAW_FIN/01_financial_index"
global FIN_STMT  "$RAW_FIN/02_financial_statements"
global FIN_BACK  "$RAW_FIN/03_financial_indicators_backup"

global DTA_IN     "$WORK/01_stata_dta"
global MATLAB_IN  "$WORK/02_matlab_input"
global MATLAB_OUT "$WORK/03_matlab_output"

global TABLE "$RESULT/01_tables"
global FIG   "$RESULT/02_figures"
global LOG   "$RESULT/03_logs"

foreach folder in "$WORK" "$RESULT" "$DTA_IN" "$MATLAB_IN" "$MATLAB_OUT" "$TABLE" "$FIG" "$LOG" {
    capture mkdir "`folder'"
}
cd "$ROOT"
