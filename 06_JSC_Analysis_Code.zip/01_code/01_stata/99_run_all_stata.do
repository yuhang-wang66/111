version 17
clear all
set more off

do "01_code/01_stata/10_prepare_panel.do"
