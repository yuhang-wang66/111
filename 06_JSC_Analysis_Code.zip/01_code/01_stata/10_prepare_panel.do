version 17
clear all
set more off

* ============================================================
* 文件名：10_prepare_panel.do
* 作用：清洗并合并样本底表、财务数据、员工数据、数字化转型数据
* 输出：
*   1) 02_work_data/01_stata_dta/panel_dea_lstm.dta
*   2) 02_work_data/02_matlab_input/panel_dea_lstm.csv
* ============================================================

do "01_code/01_stata/00_paths.do"

capture log close
log using "$LOG/10_prepare_panel.log", replace text

local y0 2013
local y1 2024

* ---------- 工具：统一股票代码为 6 位字符串 ----------
capture program drop _fix_stkcd
program define _fix_stkcd
    capture confirm variable Stkcd
    if _rc {
        capture confirm variable stkcd
        if !_rc rename stkcd Stkcd
    }
    capture confirm variable Stkcd
    if _rc {
        capture confirm variable Symbol
        if !_rc rename Symbol Stkcd
    }
    capture confirm variable Stkcd
    if _rc {
        capture confirm variable symbol
        if !_rc rename symbol Stkcd
    }
    capture confirm variable Stkcd
    if _rc {
        display as error "没有找到股票代码变量：Stkcd / stkcd / Symbol / symbol。"
        exit 111
    }

    capture confirm numeric variable Stkcd
    if !_rc {
        tostring Stkcd, replace format(%06.0f)
    }
    replace Stkcd = strtrim(Stkcd)
    replace Stkcd = subinstr(Stkcd, " ", "", .)
    replace Stkcd = substr("000000" + Stkcd, -6, 6) if Stkcd != ""
end

* ============================================================
* 1. 清洗数字化转型数据 DTI_raw.xlsx
* ============================================================
display as text "========== 1. 清洗数字化转型数据 =========="

local dti_file "$RAW_DTI/DTI_raw.xlsx"
capture confirm file "`dti_file'"
if _rc {
    display as error "找不到数字化转型数据：`dti_file'"
    display as error "请确认 结果数据.xlsx 已重命名为 DTI_raw.xlsx，并放到 00_raw_data/04_digital_transformation。"
    exit 601
}

import excel using "`dti_file'", firstrow clear

ds
local vars `r(varlist)'
local nvars : word count `vars'
if `nvars' < 3 {
    display as error "DTI_raw.xlsx 至少需要包含 股票代码、年份、数字化转型程度 三列。"
    exit 111
}

local v1 : word 1 of `vars'
local v2 : word 2 of `vars'
local vlast : word `nvars' of `vars'

if "`v1'" != "Stkcd" rename `v1' Stkcd
if "`v2'" != "year"  rename `v2' year

if `nvars' >= 4 {
    local v4 : word 4 of `vars'
    capture rename `v4' IntangibleAssets_net
}
if `nvars' >= 5 {
    local v5 : word 5 of `vars'
    capture rename `v5' DigitalIntangible
}
if "`vlast'" != "DTI" capture rename `vlast' DTI

_fix_stkcd

foreach x in year DTI DigitalIntangible IntangibleAssets_net {
    capture destring `x', replace force
}

* Remove non-data header and empty-year records.
drop if missing(year)
keep if inrange(year, `y0', `y1')

* For missing DTI values, use log-transformed digital intangible assets where available.
capture confirm variable DigitalIntangible
if !_rc {
    replace DTI = ln(1 + DigitalIntangible) if missing(DTI) & DigitalIntangible >= 0 & DigitalIntangible < .
}

drop if missing(DTI)
bysort Stkcd year: keep if _n == 1

keep Stkcd year DTI DigitalIntangible IntangibleAssets_net
save "$DTA_IN/dti_clean.dta", replace

* ============================================================
* 2. 清洗上市公司基本信息：用于筛选服务业、行业、地区
* ============================================================
display as text "========== 2. 清洗上市公司基本信息 =========="

local co_file "$RAW_COMPANY/STK_LISTEDCOINFOANL.xlsx"
capture confirm file "`co_file'"
if _rc {
    display as error "找不到上市公司基本信息表：`co_file'"
    exit 601
}

import excel using "`co_file'", firstrow clear

_fix_stkcd

capture confirm variable EndDate
if _rc {
    display as error "STK_LISTEDCOINFOANL.xlsx 中没有 EndDate 字段。"
    exit 111
}

capture confirm string variable EndDate
if !_rc {
    gen year = real(substr(EndDate, 1, 4))
}
else {
    gen year = year(EndDate)
    replace year = real(substr(string(EndDate), 1, 4)) if missing(year)
}

drop if missing(year)
keep if inrange(year, `y0', `y1')

* 统一行业代码：优先用 2023 年之后的上市公司协会分类，否则用证监会行业分类
gen str30 IndustryCode_use = ""
foreach v in IndustryCodeD IndustryCode1 IndustryCodeC IndustryCode {
    capture confirm variable `v'
    if !_rc {
        capture confirm numeric variable `v'
        if !_rc tostring `v', replace force
        replace IndustryCode_use = `v' if IndustryCode_use == "" & `v' != ""
    }
}

gen str80 IndustryName_use = ""
foreach v in IndustryNameD IndustryName1 IndustryNameC IndustryName {
    capture confirm variable `v'
    if !_rc {
        capture confirm numeric variable `v'
        if !_rc tostring `v', replace force
        replace IndustryName_use = `v' if IndustryName_use == "" & `v' != ""
    }
}

gen str1 ind_letter = substr(IndustryCode_use, 1, 1)

* 服务业行业门类：F/G/H/I/L/M/N/O/P/Q/R；剔除 J 金融业、K 房地产业
gen service = strpos("FGHILMNOPQR", ind_letter) > 0
keep if service == 1

gen str20 PROVINCE_use = ""
capture confirm variable PROVINCE
if !_rc replace PROVINCE_use = PROVINCE

gen str20 CITY_use = ""
capture confirm variable CITY
if !_rc replace CITY_use = CITY

gen str30 LISTINGSTATE_use = ""
capture confirm variable LISTINGSTATE
if !_rc replace LISTINGSTATE_use = LISTINGSTATE

local keepco Stkcd year ShortName IndustryCode_use IndustryName_use PROVINCE_use CITY_use LISTINGSTATE_use service
keep `keepco'
rename IndustryCode_use IndustryCode
rename IndustryName_use IndustryName
rename PROVINCE_use PROVINCE
rename CITY_use CITY
rename LISTINGSTATE_use LISTINGSTATE

bysort Stkcd year: keep if _n == 1
save "$DTA_IN/company_service_clean.dta", replace

* ============================================================
* 3. 清洗控制变量表：主要取 Employee1 员工人数，也保留部分控制变量
* ============================================================
display as text "========== 3. 清洗控制变量表 =========="

local ctrl_file "$RAW_CONTROL/常用控制变量-已剔除已缩尾.xlsx"
capture confirm file "`ctrl_file'"
if _rc {
    local ctrl_file "$RAW_CONTROL/常用控制变量-未剔除未缩尾.xlsx"
}
capture confirm file "`ctrl_file'"
if _rc {
    display as error "找不到控制变量表。请检查 00_raw_data/02_controls。"
    exit 601
}

import excel using "`ctrl_file'", firstrow clear
_fix_stkcd

capture confirm variable year
if _rc {
    capture confirm variable Year
    if !_rc rename Year year
}
capture confirm variable year
if _rc {
    display as error "控制变量表中没有 year 字段。"
    exit 111
}

destring year, replace force
drop if missing(year)
keep if inrange(year, `y0', `y1')

foreach x in Employee1 Employee2 Size Lev ROA ROE Growth TobinQ SOE FirmAge ListAge BH East Mid West HighTech {
    capture destring `x', replace force
}

gen Employee = .
capture confirm variable Employee1
if !_rc replace Employee = Employee1
capture confirm variable Employee2
if !_rc replace Employee = exp(Employee2) if missing(Employee) & Employee2 < .

local keepctrl Stkcd year Employee
foreach v in ShortName Size Lev ROA ROE Growth TobinQ SOE FirmAge ListAge BH East Mid West HighTech {
    capture confirm variable `v'
    if !_rc local keepctrl `keepctrl' `v'
}
keep `keepctrl'
bysort Stkcd year: keep if _n == 1
save "$DTA_IN/controls_clean.dta", replace

* 如果 FAR_Finidx.dta 存在，用 Nstaff 补员工人数
local far_file "$FIN_INDEX/FAR_Finidx.dta"
capture confirm file "`far_file'"
if !_rc {
    use "`far_file'", clear
    _fix_stkcd

    capture confirm variable Accper
    if !_rc {
        capture confirm string variable Accper
        if !_rc gen year = real(substr(Accper, 1, 4))
        else {
            gen year = year(Accper)
            replace year = real(substr(string(Accper), 1, 4)) if missing(year)
        }
    }

    keep if inrange(year, `y0', `y1')
    capture confirm variable Nstaff
    if !_rc {
        destring Nstaff, replace force
        rename Nstaff Employee_far
        keep Stkcd year Employee_far
        bysort Stkcd year: keep if _n == 1
        save "$DTA_IN/employee_far_clean.dta", replace

        use "$DTA_IN/controls_clean.dta", clear
        merge 1:1 Stkcd year using "$DTA_IN/employee_far_clean.dta", keep(1 3) nogen
        replace Employee = Employee_far if missing(Employee) & Employee_far < .
        drop Employee_far
        save "$DTA_IN/controls_clean.dta", replace
    }
}

* ============================================================
* 4. 清洗财务数据：优先 AIQ_LCFinIndexY，其次 BDT_FinIndex
* ============================================================
display as text "========== 4. 清洗财务数据 =========="

local fin_file "$FIN_INDEX/AIQ_LCFinIndexY.dta"
capture confirm file "`fin_file'"
if _rc {
    local fin_file "$FIN_INDEX/BDT_FinIndex.dta"
}
capture confirm file "`fin_file'"
if _rc {
    display as error "找不到 AIQ_LCFinIndexY.dta 或 BDT_FinIndex.dta。"
    display as error "请把正式 .dta 数据放到：00_raw_data/03_financial_data/01_financial_index。"
    exit 601
}

use "`fin_file'", clear
_fix_stkcd

capture confirm variable EndDate
if !_rc {
    capture confirm string variable EndDate
    if !_rc {
        gen year = real(substr(EndDate, 1, 4))
        keep if substr(EndDate, 6, 5) == "12-31" | strlen(EndDate) < 10
    }
    else {
        gen year = year(EndDate)
        replace year = real(substr(string(EndDate), 1, 4)) if missing(year)
    }
}
else {
    capture confirm variable Accper
    if !_rc {
        capture confirm string variable Accper
        if !_rc {
            gen year = real(substr(Accper, 1, 4))
            keep if substr(Accper, 6, 5) == "12-31" | strlen(Accper) < 10
        }
        else {
            gen year = year(Accper)
            replace year = real(substr(string(Accper), 1, 4)) if missing(year)
        }
    }
}

keep if inrange(year, `y0', `y1')

capture confirm variable StateType
if !_rc keep if StateType == "A" | StateType == "合并报表" | StateType == ""
capture confirm variable Typrep
if !_rc keep if Typrep == "A" | Typrep == "合并报表" | Typrep == ""

foreach x in TotalAssets OperatingRevenue RDExpenses AssetLiabilityRatio ROAA ROAB ROAC ROA {
    capture destring `x', replace force
}

capture confirm variable TotalAssets
if _rc {
    display as error "财务数据中没有 TotalAssets，总资产变量缺失。"
    exit 111
}

capture confirm variable OperatingRevenue
if _rc {
    display as error "财务数据中没有 OperatingRevenue，营业收入变量缺失。"
    exit 111
}

local keepfin Stkcd year TotalAssets OperatingRevenue
foreach v in RDExpenses AssetLiabilityRatio ROAA ROAB ROAC ROA {
    capture confirm variable `v'
    if !_rc local keepfin `keepfin' `v'
}
keep `keepfin'

bysort Stkcd year: keep if _n == 1
save "$DTA_IN/finance_clean.dta", replace

* ============================================================
* 5. 合并总面板
* ============================================================
display as text "========== 5. 合并总面板 =========="

use "$DTA_IN/company_service_clean.dta", clear
merge 1:1 Stkcd year using "$DTA_IN/finance_clean.dta", keep(3) nogen
merge 1:1 Stkcd year using "$DTA_IN/controls_clean.dta", keep(1 3) nogen
merge 1:1 Stkcd year using "$DTA_IN/dti_clean.dta", keep(3) nogen

* 如果没有员工人数，不能进入主模型；如果总资产缺失但 Size 存在，先用 exp(Size) 将就补总资产
capture confirm variable Size
if !_rc replace TotalAssets = exp(Size) if missing(TotalAssets) & Size < .

drop if missing(TotalAssets, Employee, OperatingRevenue, DTI)
drop if TotalAssets <= 0 | Employee <= 0 | OperatingRevenue <= 0

* 极端值处理：按年份 1% 和 99% 缩尾，不依赖 winsor2
foreach v in TotalAssets Employee OperatingRevenue DTI {
    tempvar p1 p99
    bysort year: egen `p1' = pctile(`v'), p(1)
    bysort year: egen `p99' = pctile(`v'), p(99)
    replace `v' = `p1' if `v' < `p1' & !missing(`v', `p1')
    replace `v' = `p99' if `v' > `p99' & !missing(`v', `p99')
    drop `p1' `p99'
}

* DEA 变量缩放：避免 MATLAB 线性规划数值过大
gen Asset_100m = TotalAssets / 100000000
gen Revenue_100m = OperatingRevenue / 100000000

* DEA 要求产出非负/正值：如果 DTI 有负值，整体平移；否则加极小正数
summarize DTI, meanonly
gen DTI_pos = DTI
if r(min) <= 0 {
    replace DTI_pos = DTI - r(min) + 0.000001
}
else {
    replace DTI_pos = DTI + 0.000001
}

capture confirm variable RDExpenses
if _rc gen RDExpenses = .

order Stkcd year ShortName IndustryCode IndustryName PROVINCE CITY LISTINGSTATE ///
      TotalAssets Asset_100m Employee OperatingRevenue Revenue_100m DTI DTI_pos ///
      DigitalIntangible RDExpenses

sort Stkcd year
save "$DTA_IN/panel_dea_lstm.dta", replace
export delimited using "$MATLAB_IN/panel_dea_lstm.csv", replace

* 输出年度样本量和关键变量均值，方便检查
preserve
collapse (count) N=year ///
         (mean) mean_asset=Asset_100m mean_employee=Employee mean_revenue=Revenue_100m mean_dti=DTI_pos, by(year)
export excel using "$TABLE/样本年度概况.xlsx", replace firstrow(variables)
restore

* 输出行业样本量，方便检查
preserve
collapse (count) N=year, by(IndustryCode IndustryName)
gsort -N
export excel using "$TABLE/样本行业分布.xlsx", replace firstrow(variables)
restore

display as result "完成：已生成 $DTA_IN/panel_dea_lstm.dta"
display as result "完成：已生成 $MATLAB_IN/panel_dea_lstm.csv"

log close
