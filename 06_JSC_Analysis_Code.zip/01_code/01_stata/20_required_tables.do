/********************************************************************
  20_required_tables.do
  Purpose:
    Generate necessary empirical tables after DEA/LSTM results.

  Imported variable names are standardized to lowercase for consistency.
********************************************************************/

clear all
set more off

* 1. Load unified paths
capture noisily do "01_code/01_stata/00_paths.do"
if _rc {
    global ROOT "`c(pwd)'"
    global WORK "$ROOT/02_work_data"
    global RESULT "$ROOT/03_results"
    global MATLAB_OUT "$WORK/03_matlab_output"
    global TABLE "$RESULT/01_tables"
    global FIG "$RESULT/02_figures"
    global LOG "$RESULT/03_logs"
}

cap mkdir "$TABLE"
cap mkdir "$FIG"
cap mkdir "$LOG"

capture log close
log using "$LOG/20_required_tables.log", replace text

* ================================================================
* A. Load DEA results
* ================================================================

local dea_file "$MATLAB_OUT/dea_results.csv"
capture confirm file "`dea_file'"
if _rc {
    di as error "Cannot find `dea_file'. Please run MATLAB m01_run_sbm_dea.m first."
    exit 601
}

import delimited using "`dea_file'", clear varnames(1) bindquote(strict) encoding(UTF-8)

* Standardize all variable names to lowercase
rename *, lower

* Check whether the key DEA variable exists
capture confirm variable eff
if _rc {
    di as error "The variable eff is not found after importing dea_results.csv."
    di as error "Please check whether dea_results.csv contains the DEA efficiency column."
    describe
    exit 111
}

* Convert key numeric variables if imported as strings
foreach v in year totalassets asset_100m employee operatingrevenue revenue_100m dti dti_pos digitalintangible rdexpenses eff r_asset r_employee r_dti r_revenue east mid west soe hightech roa roe growth tobinq lev size listage firmage {
    capture confirm variable `v'
    if !_rc {
        capture destring `v', replace force
    }
}

* Keep valid DEA observations
keep if !missing(eff)

* Create English variable labels for tables
capture label var asset_100m        "Total assets / 100 million RMB"
capture label var employee          "Number of employees"
capture label var revenue_100m      "Operating revenue / 100 million RMB"
capture label var dti               "Digital transformation degree"
capture label var digitalintangible "Digital transformation intangible assets"
capture label var eff               "SBM-DEA efficiency"
capture label var r_asset           "Capital input redundancy ratio"
capture label var r_employee        "Labor input redundancy ratio"
capture label var r_dti             "Digital output insufficiency ratio"
capture label var r_revenue         "Revenue output insufficiency ratio"

* ------------------------
* Table 1: Descriptive statistics
* ------------------------
tempname memhold
postfile `memhold' str60 Variable double N Mean SD Min Median Max using "$TABLE/descriptive_temp.dta", replace

local desc_vars asset_100m employee revenue_100m dti digitalintangible eff r_asset r_employee r_dti r_revenue
foreach v of local desc_vars {
    capture confirm variable `v'
    if !_rc {
        quietly summarize `v', detail
        local lab : variable label `v'
        if "`lab'" == "" local lab "`v'"
        post `memhold' ("`lab'") (r(N)) (r(mean)) (r(sd)) (r(min)) (r(p50)) (r(max))
    }
}
postclose `memhold'

preserve
use "$TABLE/descriptive_temp.dta", clear
format N %12.0f
format Mean SD Min Median Max %12.4f
export excel using "$TABLE/Table1_descriptive_statistics.xlsx", replace firstrow(variables)
restore

* ------------------------
* Table 2: Annual efficiency summary
* ------------------------
preserve
collapse (count) N=eff (mean) MeanEff=eff (median) MedianEff=eff (sd) SDEff=eff, by(year)
tempfile annual_base
save `annual_base', replace
restore

preserve
gen efficient = eff >= 0.999999 if !missing(eff)
collapse (mean) EfficientRatio=efficient, by(year)
merge 1:1 year using `annual_base', nogen
order year N MeanEff MedianEff SDEff EfficientRatio
format MeanEff MedianEff SDEff EfficientRatio %12.4f
export excel using "$TABLE/Table2_annual_efficiency_summary.xlsx", replace firstrow(variables)
restore

* ------------------------
* Table 3: Industry efficiency differences
* ------------------------
preserve
capture confirm variable industrycode
if _rc gen industrycode = "Unknown"
capture confirm variable industryname
if _rc gen industryname = "Unknown"

replace industrycode = "Unknown" if industrycode == ""
replace industryname = "Unknown" if industryname == ""

collapse (count) N=eff (mean) MeanEff=eff (median) MedianEff=eff (sd) SDEff=eff, by(industrycode industryname)
gsort -MeanEff
format MeanEff MedianEff SDEff %12.4f
export excel using "$TABLE/Table3_industry_efficiency.xlsx", replace firstrow(variables)
restore

* ------------------------
* Table 4: Region efficiency differences
* ------------------------
preserve
capture confirm variable province
if _rc gen province = ""

gen Region = "Other"

* If East/Mid/West dummies exist, use them first
capture confirm variable east
if !_rc {
    replace Region = "Eastern China" if east == 1
}
capture confirm variable mid
if !_rc {
    replace Region = "Central China" if mid == 1
}
capture confirm variable west
if !_rc {
    replace Region = "Western China" if west == 1
}

* Identify Northeast provinces if province names are available
replace Region = "Northeast China" if inlist(province, "辽宁省", "吉林省", "黑龙江省")
replace Region = "Northeast China" if inlist(province, "辽宁", "吉林", "黑龙江")
replace Region = "Other" if Region == ""

collapse (count) N=eff (mean) MeanEff=eff (median) MedianEff=eff (sd) SDEff=eff, by(Region)
gsort Region
format MeanEff MedianEff SDEff %12.4f
export excel using "$TABLE/Table4_region_efficiency.xlsx", replace firstrow(variables)
restore

* ================================================================
* B. Path classification summaries
* ================================================================

local path_file "$MATLAB_OUT/path_classification_2024.csv"
capture confirm file "`path_file'"
if _rc {
    di as txt "Path classification file not found. Skip path summary tables."
}
else {
    import delimited using "`path_file'", clear varnames(1) bindquote(strict) encoding(UTF-8)
    rename *, lower

    foreach v in eff eff_current eff_pred_next eti maxslackratio r_asset r_employee r_dti r_revenue {
        capture confirm variable `v'
        if !_rc {
            capture destring `v', replace force
        }
    }

    capture confirm variable type
    if _rc {
        di as error "Variable type is not found in path_classification_2024.csv."
        describe
        exit 111
    }

    preserve
    collapse (count) N=eff_current (mean) MeanEff=eff_current MeanETI=eti, by(type)
    gsort type
    format MeanEff MeanETI %12.4f
    export excel using "$TABLE/Table5_path_type_summary.xlsx", replace firstrow(variables)
    restore

    capture confirm variable maindiagnosis
    if !_rc {
        preserve
        collapse (count) N=maxslackratio (mean) MeanSlackRatio=maxslackratio, by(maindiagnosis)
        gsort -N
        format MeanSlackRatio %12.4f
        export excel using "$TABLE/Table6_diagnosis_summary.xlsx", replace firstrow(variables)
        restore
    }
}

log close

di as result "Required Stata tables are done. Please check: $TABLE"
