function [eff, sx, sy] = sbm_vrs(X, Y)
% SBM_VRS Non-oriented SBM-DEA with VRS assumption.
% X: n*m positive input matrix; Y: n*s positive output matrix.

X = double(X);
Y = double(Y);
[n, m] = size(X);
[n2, s] = size(Y);

if n ~= n2
    error('X and Y must have the same number of rows.');
end
if any(X(:) <= 0) || any(Y(:) <= 0)
    error('SBM-DEA requires positive input and output values.');
end

eff = nan(n, 1);
sx = nan(n, m);
sy = nan(n, s);

try
    opts = optimoptions('linprog', 'Display', 'none', 'Algorithm', 'dual-simplex');
catch
    try
        opts = optimoptions('linprog', 'Display', 'none');
    catch
        opts = optimset('Display', 'off');
    end
end

for o = 1:n
    x0 = X(o, :)';
    y0 = Y(o, :)';

    f = [zeros(n, 1); -(1/m) ./ x0; zeros(s, 1); 1];

    Aeq = [
        X', eye(m), zeros(m, s), -x0;
        Y', zeros(s, m), -eye(s), -y0;
        ones(1, n), zeros(1, m+s), -1;
        zeros(1, n+m), (1/s) ./ y0', 1
    ];

    beq = [zeros(m+s, 1); 0; 1];
    lb = zeros(n + m + s + 1, 1);

    try
        [z, fval, exitflag] = linprog(f, [], [], Aeq, beq, lb, [], opts);
    catch
        [z, fval, exitflag] = linprog(f, [], [], Aeq, beq, lb, [], [], opts);
    end

    if exitflag > 0 && ~isempty(z)
        tau = z(end);
        if tau > 1e-12
            eff(o) = min(max(fval, 0), 1);
            sx(o, :) = z(n+1:n+m)' ./ tau;
            sy(o, :) = z(n+m+1:n+m+s)' ./ tau;
        end
    end

    if mod(o, 100) == 0
        fprintf('  SBM solved %d / %d DMUs\n', o, n);
    end
end
end
