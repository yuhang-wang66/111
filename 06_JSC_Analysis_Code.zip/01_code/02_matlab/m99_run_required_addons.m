clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm05_model_comparison.m'));
run(fullfile(fileparts(mfilename('fullpath')), 'm06_robust_alt_dti.m'));
run(fullfile(fileparts(mfilename('fullpath')), 'm07_robust_exclude_it.m'));
run(fullfile(fileparts(mfilename('fullpath')), 'm08_winsor_path_diagnosis.m'));
fprintf('\nAll required add-on analyses are completed.\n');
