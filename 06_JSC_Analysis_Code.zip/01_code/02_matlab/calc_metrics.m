function [mae, rmse, r2] = calc_metrics(ytrue, ypred)
ytrue = double(ytrue(:));
ypred = double(ypred(:));
ok = ~isnan(ytrue) & ~isnan(ypred);
ytrue = ytrue(ok);
ypred = ypred(ok);
if isempty(ytrue)
    mae = NaN; rmse = NaN; r2 = NaN; return;
end
mae = mean(abs(ypred - ytrue));
rmse = sqrt(mean((ypred - ytrue).^2));
den = sum((ytrue - mean(ytrue)).^2);
if den <= 0
    r2 = NaN;
else
    r2 = 1 - sum((ypred - ytrue).^2) / den;
end
end
