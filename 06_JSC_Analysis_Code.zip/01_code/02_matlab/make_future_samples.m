function [Xfuture, Fid, CurrentYear, CurrentEff] = make_future_samples(T, featureVars, seqLen, lastYear)
% lastYear-seqLen+1 to lastYear -> lastYear+1.

ids = unique(T.Stkcd);
Xfuture = {};
Fid = {};
CurrentYear = [];
CurrentEff = [];

yearsWanted = (lastYear - seqLen + 1):lastYear;

for i = 1:length(ids)
    id = ids{i};
    Ti = T(strcmp(T.Stkcd, id), :);
    Ti = sortrows(Ti, 'year');

    [tf, loc] = ismember(yearsWanted, Ti.year);
    if ~all(tf)
        continue;
    end

    X = Ti{loc, featureVars}';
    if any(isnan(X(:)))
        continue;
    end

    Xfuture{end+1, 1} = X; %#ok<AGROW>
    Fid{end+1, 1} = id; %#ok<AGROW>
    CurrentYear(end+1, 1) = lastYear; %#ok<AGROW>
    CurrentEff(end+1, 1) = Ti.Eff_raw(loc(end)); %#ok<AGROW>
end
end
