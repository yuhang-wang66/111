function y = winsor_vec(x, p_low, p_high)
% Winsorize vector x at p_low and p_high percentiles without requiring Statistics Toolbox.
x = double(x);
y = x;
ok = ~isnan(x);
if sum(ok) < 5
    return;
end
xs = sort(x(ok));
n = numel(xs);
lo_pos = max(1, round(p_low / 100 * n));
hi_pos = min(n, round(p_high / 100 * n));
lo = xs(lo_pos);
hi = xs(hi_pos);
y(ok & y < lo) = lo;
y(ok & y > hi) = hi;
end
