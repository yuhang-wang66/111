clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm00_paths.m'));

infile = fullfile(MATLAB_IN, 'panel_dea_lstm.csv');
mainFile = fullfile(MATLAB_OUT, 'dea_results.csv');

if exist(infile, 'file') ~= 2
    error('Cannot find input file: %s. Please run Stata 10_prepare_panel.do first.', infile);
end
if exist(mainFile, 'file') ~= 2
    error('Cannot find main DEA result: %s. Please run m01_run_sbm_dea.m first.', mainFile);
end

T = readtable(infile);
T = normalize_stkcd_in_table(T);

required = {'year','Asset_100m','Employee','Revenue_100m','DigitalIntangible'};
for i = 1:numel(required)
    if ~ismember(required{i}, T.Properties.VariableNames)
        error('Missing variable: %s. Robustness with alternative DTI cannot run.', required{i});
    end
    T.(required{i}) = to_numeric_col(T.(required{i}));
end

% Alternative digital transformation output: ln(1 + max(DigitalIntangible, 0)).
T.DTI_alt = log(1 + max(T.DigitalIntangible, 0));
T.DTI_alt_pos = T.DTI_alt + 1e-6;

T.Eff_alt = nan(height(T), 1);
T.slack_asset_alt = nan(height(T), 1);
T.slack_employee_alt = nan(height(T), 1);
T.slack_dti_alt = nan(height(T), 1);
T.slack_revenue_alt = nan(height(T), 1);

years = unique(T.year);
years = sort(years(~isnan(years)));

for k = 1:length(years)
    y = years(k);
    valid = T.year == y & ...
        ~isnan(T.Asset_100m) & ~isnan(T.Employee) & ~isnan(T.DTI_alt_pos) & ~isnan(T.Revenue_100m) & ...
        T.Asset_100m > 0 & T.Employee > 0 & T.DTI_alt_pos > 0 & T.Revenue_100m > 0;

    rows = find(valid);
    fprintf('\nAlternative DTI robustness, Year %d: DMUs = %d\n', y, numel(rows));
    if numel(rows) < 10
        warning('Year %d has fewer than 10 DMUs; skipped.', y);
        continue;
    end

    X = [T.Asset_100m(rows), T.Employee(rows)];
    Y = [T.DTI_alt_pos(rows), T.Revenue_100m(rows)];

    [eff, sx, sy] = sbm_vrs(X, Y);
    T.Eff_alt(rows) = eff;
    T.slack_asset_alt(rows) = sx(:, 1);
    T.slack_employee_alt(rows) = sx(:, 2);
    T.slack_dti_alt(rows) = sy(:, 1);
    T.slack_revenue_alt(rows) = sy(:, 2);
end

T.r_asset_alt = T.slack_asset_alt ./ T.Asset_100m;
T.r_employee_alt = T.slack_employee_alt ./ T.Employee;
T.r_dti_alt = T.slack_dti_alt ./ T.DTI_alt_pos;
T.r_revenue_alt = T.slack_revenue_alt ./ T.Revenue_100m;

writetable(T, fullfile(MATLAB_OUT, 'robust_alt_dti_results.csv'));

% Annual summary.
S_year = unique(T.year(~isnan(T.year)));
N = zeros(numel(S_year),1); MeanEff = nan(numel(S_year),1); MedianEff = nan(numel(S_year),1); EfficientRatio = nan(numel(S_year),1);
for i = 1:numel(S_year)
    yy = S_year(i);
    v = T.Eff_alt(T.year == yy & ~isnan(T.Eff_alt));
    N(i) = numel(v);
    if ~isempty(v)
        MeanEff(i) = mean(v);
        MedianEff(i) = median(v);
        EfficientRatio(i) = mean(v >= 0.999999);
    end
end
AltYearSummary = table(S_year, N, MeanEff, MedianEff, EfficientRatio, ...
    'VariableNames', {'year','N','MeanEff_alt','MedianEff_alt','EfficientRatio_alt'});
writetable(AltYearSummary, fullfile(TABLE, 'Robustness1_alt_DTI_year_summary.xlsx'));

% Correlation with main DEA efficiency.
M = readtable(mainFile);
M = normalize_stkcd_in_table(M);
M.year = to_numeric_col(M.year);
M.Eff = to_numeric_col(M.Eff);
MainKeep = M(:, {'Stkcd','year','Eff'});
AltKeep = T(:, {'Stkcd','year','Eff_alt'});
J = innerjoin(MainKeep, AltKeep, 'Keys', {'Stkcd','year'});
ok = ~isnan(J.Eff) & ~isnan(J.Eff_alt);
if sum(ok) >= 3
    x = J.Eff(ok);
    y = J.Eff_alt(ok);
    C = corrcoef(x, y);
    PearsonCorr = C(1,2);
    rx = rank_vec(x);
    ry = rank_vec(y);
    C2 = corrcoef(rx, ry);
    SpearmanCorr = C2(1,2);
else
    PearsonCorr = NaN; SpearmanCorr = NaN;
end
RobustCorr = table(PearsonCorr, SpearmanCorr, sum(ok), 'VariableNames', {'PearsonCorr','SpearmanCorr','N'});
writetable(RobustCorr, fullfile(TABLE, 'Robustness1_alt_DTI_correlation.xlsx'));

disp(RobustCorr);
fprintf('\nAlternative DTI robustness is done. Outputs are in %s and %s\n', MATLAB_OUT, TABLE);
