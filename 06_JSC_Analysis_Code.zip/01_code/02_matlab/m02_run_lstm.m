clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm00_paths.m'));

rng(202405);

deaFile = fullfile(MATLAB_OUT, 'dea_results.csv');
if exist(deaFile, 'file') ~= 2
    error('Cannot find DEA results: %s. Please run m01_run_sbm_dea.m first.', deaFile);
end

T = readtable(deaFile);
T = normalize_stkcd_in_table(T);

numVars = {'year','Eff','Asset_100m','Employee','DTI_pos','Revenue_100m'};
for i = 1:numel(numVars)
    if ismember(numVars{i}, T.Properties.VariableNames)
        T.(numVars{i}) = to_numeric_col(T.(numVars{i}));
    end
end

T = T(~isnan(T.Eff), :);
T = sortrows(T, {'Stkcd','year'});
T.Eff_raw = T.Eff;

featureVars = {'Eff', 'Asset_100m', 'Employee', 'DTI_pos', 'Revenue_100m'};
seqLen = 3;

trainRows = T.year <= 2020;
Xall = T{:, featureVars};
mu = zeros(1, size(Xall,2));
sigma = ones(1, size(Xall,2));
for j = 1:size(Xall,2)
    v = Xall(trainRows, j);
    v = v(~isnan(v));
    if isempty(v)
        mu(j) = 0;
        sigma(j) = 1;
    else
        mu(j) = mean(v);
        sigma(j) = std(v, 0);
        if sigma(j) == 0 || isnan(sigma(j))
            sigma(j) = 1;
        end
    end
end
T{:, featureVars} = bsxfun(@rdivide, bsxfun(@minus, T{:, featureVars}, mu), sigma);

[Xseq, Ytar, Yyear, Yid] = make_lstm_samples(T, featureVars, seqLen);

if isempty(Xseq)
    error('No LSTM samples. Please check whether firm-year observations are continuous for at least 4 years.');
end

idxTrain = Yyear <= 2020;
idxVal = Yyear >= 2021 & Yyear <= 2022;
idxTest = Yyear >= 2023 & Yyear <= 2024;

XTrain = Xseq(idxTrain);
YTrain = Ytar(idxTrain);
XVal = Xseq(idxVal);
YVal = Ytar(idxVal);
XTest = Xseq(idxTest);
YTest = Ytar(idxTest);
YidTest = Yid(idxTest);
YyearTest = Yyear(idxTest);

fprintf('LSTM samples: train=%d, val=%d, test=%d\n', numel(YTrain), numel(YVal), numel(YTest));

numFeatures = length(featureVars);

layers = [
    sequenceInputLayer(numFeatures)
    lstmLayer(32, 'OutputMode', 'last')
    dropoutLayer(0.1)
    fullyConnectedLayer(1)
    regressionLayer
];

if ~isempty(XVal)
    options = trainingOptions('adam', ...
        'MaxEpochs', 120, ...
        'MiniBatchSize', 64, ...
        'InitialLearnRate', 0.005, ...
        'ValidationData', {XVal, YVal}, ...
        'ValidationFrequency', 20, ...
        'Shuffle', 'every-epoch', ...
        'Verbose', false, ...
        'Plots', 'training-progress');
else
    options = trainingOptions('adam', ...
        'MaxEpochs', 120, ...
        'MiniBatchSize', 64, ...
        'InitialLearnRate', 0.005, ...
        'Shuffle', 'every-epoch', ...
        'Verbose', false, ...
        'Plots', 'training-progress');
end

net = trainNetwork(XTrain, YTrain, layers, options);

if ~isempty(XTest)
    YPred = predict(net, XTest, 'MiniBatchSize', 128);
    YPred_clip = min(max(YPred, 0), 1);

    MAE = mean(abs(YPred_clip - YTest));
    RMSE = sqrt(mean((YPred_clip - YTest).^2));
    den = sum((YTest - mean(YTest)).^2);
    if den == 0
        R2 = NaN;
    else
        R2 = 1 - sum((YPred_clip - YTest).^2) / den;
    end
else
    YPred_clip = [];
    MAE = NaN;
    RMSE = NaN;
    R2 = NaN;
end

fprintf('LSTM Test MAE  = %.4f\n', MAE);
fprintf('LSTM Test RMSE = %.4f\n', RMSE);
fprintf('LSTM Test R2   = %.4f\n', R2);

metrics = table({'LSTM'}, MAE, RMSE, R2, ...
    'VariableNames', {'Model','MAE','RMSE','R2'});
writetable(metrics, fullfile(TABLE, 'lstm_metrics.xlsx'));

if ~isempty(XTest)
    predTbl = table(YidTest(:), YyearTest(:), YTest(:), YPred_clip(:), YPred_clip(:) - YTest(:), ...
        'VariableNames', {'Stkcd','TargetYear','Eff_actual','Eff_pred','PredError'});
    writetable(predTbl, fullfile(MATLAB_OUT, 'lstm_test_predictions.csv'));
end

% Use 2022-2024 data to forecast 2025 efficiency trend.
lastYear = 2024;
[Xfuture, Fid, CurrentYear, CurrentEff] = make_future_samples(T, featureVars, seqLen, lastYear);

if isempty(Xfuture)
    warning('No future forecast samples. Please check whether 2022-2024 consecutive observations exist.');
else
    Eff_pred_next = predict(net, Xfuture, 'MiniBatchSize', 128);
    Eff_pred_next = min(max(Eff_pred_next, 0), 1);
    ETI = Eff_pred_next - CurrentEff;

    futureTbl = table(Fid(:), CurrentYear(:), CurrentEff(:), Eff_pred_next(:), ETI(:), ...
        'VariableNames', {'Stkcd','CurrentYear','Eff_current','Eff_pred_next','ETI'});

    writetable(futureTbl, fullfile(MATLAB_OUT, 'lstm_future_2025.csv'));
    writetable(futureTbl, fullfile(TABLE, 'future_warning_2025.xlsx'));
    fprintf('Future prediction saved: lstm_future_2025.csv\n');
end
