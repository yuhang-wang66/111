function [Xseq, Ytar, Yyear, Yid] = make_lstm_samples(T, featureVars, seqLen)
% Past seqLen years -> next-year DEA efficiency.

ids = unique(T.Stkcd);
Xseq = {};
Ytar = [];
Yyear = [];
Yid = {};

for i = 1:length(ids)
    id = ids{i};
    Ti = T(strcmp(T.Stkcd, id), :);
    Ti = sortrows(Ti, 'year');

    if height(Ti) <= seqLen
        continue;
    end

    for j = 1:(height(Ti) - seqLen)
        inputYears = Ti.year(j:j+seqLen-1);
        targetYear = Ti.year(j+seqLen);
        allYears = [inputYears; targetYear];

        if any(diff(allYears) ~= 1)
            continue;
        end

        X = Ti{j:j+seqLen-1, featureVars}';
        y = Ti.Eff_raw(j+seqLen);

        if any(isnan(X(:))) || isnan(y)
            continue;
        end

        Xseq{end+1, 1} = X; %#ok<AGROW>
        Ytar(end+1, 1) = y; %#ok<AGROW>
        Yyear(end+1, 1) = targetYear; %#ok<AGROW>
        Yid{end+1, 1} = id; %#ok<AGROW>
    end
end
end
