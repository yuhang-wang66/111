function r = rank_vec(x)
% Simple average rank for a numeric vector, handling ties.
x = double(x(:));
r = nan(size(x));
ok = ~isnan(x);
idx = find(ok);
xs = x(ok);
[sorted, ord] = sort(xs);
n = numel(xs);
rank_sorted = nan(n,1);
i = 1;
while i <= n
    j = i;
    while j < n && sorted(j+1) == sorted(i)
        j = j + 1;
    end
    rank_sorted(i:j) = mean(i:j);
    i = j + 1;
end
r(idx(ord)) = rank_sorted;
end
