clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm00_paths.m'));

infile = fullfile(MATLAB_IN, 'panel_dea_lstm.csv');
if exist(infile, 'file') ~= 2
    error('Cannot find MATLAB input file: %s. Please run Stata 10_prepare_panel.do first.', infile);
end

T = readtable(infile);
T = normalize_stkcd_in_table(T);

required = {'year', 'Asset_100m', 'Employee', 'DTI_pos', 'Revenue_100m'};
for i = 1:numel(required)
    if ~ismember(required{i}, T.Properties.VariableNames)
        error('Missing variable: %s. Please check panel_dea_lstm.csv.', required{i});
    end
    T.(required{i}) = to_numeric_col(T.(required{i}));
end

T.Eff = nan(height(T), 1);
T.slack_asset = nan(height(T), 1);
T.slack_employee = nan(height(T), 1);
T.slack_dti = nan(height(T), 1);
T.slack_revenue = nan(height(T), 1);

years = unique(T.year);
years = years(~isnan(years));
years = sort(years);

for k = 1:length(years)
    y = years(k);
    idx = T.year == y;

    valid = idx & ...
        ~isnan(T.Asset_100m) & ~isnan(T.Employee) & ~isnan(T.DTI_pos) & ~isnan(T.Revenue_100m) & ...
        T.Asset_100m > 0 & T.Employee > 0 & T.DTI_pos > 0 & T.Revenue_100m > 0;

    rows = find(valid);
    fprintf('\nYear %d: DMUs = %d\n', y, numel(rows));

    if numel(rows) < 10
        warning('Year %d has fewer than 10 DMUs; skipped.', y);
        continue;
    end

    X = [T.Asset_100m(rows), T.Employee(rows)];
    Y = [T.DTI_pos(rows), T.Revenue_100m(rows)];

    [eff, sx, sy] = sbm_vrs(X, Y);

    T.Eff(rows) = eff;
    T.slack_asset(rows) = sx(:, 1);
    T.slack_employee(rows) = sx(:, 2);
    T.slack_dti(rows) = sy(:, 1);
    T.slack_revenue(rows) = sy(:, 2);
end

T.r_asset = T.slack_asset ./ T.Asset_100m;
T.r_employee = T.slack_employee ./ T.Employee;
T.r_dti = T.slack_dti ./ T.DTI_pos;
T.r_revenue = T.slack_revenue ./ T.Revenue_100m;

outfile = fullfile(MATLAB_OUT, 'dea_results.csv');
writetable(T, outfile);
fprintf('\nDEA results saved to: %s\n', outfile);

% Yearly summary
years2 = unique(T.year(~isnan(T.Eff)));
N = zeros(numel(years2), 1);
MeanEff = zeros(numel(years2), 1);
MedianEff = zeros(numel(years2), 1);
EfficientRatio = zeros(numel(years2), 1);

for i = 1:numel(years2)
    yy = years2(i);
    e = T.Eff(T.year == yy);
    e = e(~isnan(e));
    N(i) = numel(e);
    MeanEff(i) = mean(e);
    MedianEff(i) = median(e);
    EfficientRatio(i) = mean(e >= 0.999);
end

summaryTbl = table(years2, N, MeanEff, MedianEff, EfficientRatio, ...
    'VariableNames', {'year','N','MeanEff','MedianEff','EfficientRatio'});

writetable(summaryTbl, fullfile(TABLE, 'dea_year_summary.xlsx'));
fprintf('DEA summary table saved.\n');
