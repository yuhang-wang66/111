% Project path settings. This file infers ROOT from its own location.
% Folder structure expected: ROOT/01_code/02_matlab/m00_paths.m

thisFile = mfilename('fullpath');
CODE_MATLAB = fileparts(thisFile);
CODE = fileparts(CODE_MATLAB);
ROOT = fileparts(CODE);

RAW = fullfile(ROOT, '00_raw_data');
WORK = fullfile(ROOT, '02_work_data');
RESULT = fullfile(ROOT, '03_results');
PAPER = fullfile(ROOT, '04_paper');

RAW_COMPANY = fullfile(RAW, '01_company_info');
RAW_CONTROL = fullfile(RAW, '02_controls');
RAW_FIN = fullfile(RAW, '03_financial_data');
RAW_DTI = fullfile(RAW, '04_digital_transformation');

DTA_IN = fullfile(WORK, '01_stata_dta');
MATLAB_IN = fullfile(WORK, '02_matlab_input');
MATLAB_OUT = fullfile(WORK, '03_matlab_output');

TABLE = fullfile(RESULT, '01_tables');
FIG = fullfile(RESULT, '02_figures');
LOG = fullfile(RESULT, '03_logs');

if exist(MATLAB_OUT, 'dir') ~= 7, mkdir(MATLAB_OUT); end
if exist(TABLE, 'dir') ~= 7, mkdir(TABLE); end
if exist(FIG, 'dir') ~= 7, mkdir(FIG); end
if exist(LOG, 'dir') ~= 7, mkdir(LOG); end

addpath(CODE_MATLAB);
