clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm00_paths.m'));

rng(202405);

deaFile = fullfile(MATLAB_OUT, 'dea_results.csv');
if exist(deaFile, 'file') ~= 2
    error('Cannot find DEA result file: %s. Please run m01_run_sbm_dea.m first.', deaFile);
end

T = readtable(deaFile);
T = normalize_stkcd_in_table(T);

numVars = {'year','Eff','Asset_100m','Employee','DTI_pos','Revenue_100m'};
for i = 1:numel(numVars)
    if ismember(numVars{i}, T.Properties.VariableNames)
        T.(numVars{i}) = to_numeric_col(T.(numVars{i}));
    else
        error('Missing variable %s in dea_results.csv.', numVars{i});
    end
end

T = T(~isnan(T.Eff), :);
T = sortrows(T, {'Stkcd','year'});
T.Eff_raw = T.Eff;

featureVars = {'Eff', 'Asset_100m', 'Employee', 'DTI_pos', 'Revenue_100m'};
seqLen = 3;

% Standardize with training-period statistics, consistent with LSTM script.
trainRows = T.year <= 2020;
Xall = T{:, featureVars};
mu = zeros(1, size(Xall,2));
sigma = ones(1, size(Xall,2));
for j = 1:size(Xall,2)
    v = Xall(trainRows, j);
    v = v(~isnan(v));
    if ~isempty(v)
        mu(j) = mean(v);
        sigma(j) = std(v, 0);
        if sigma(j) == 0 || isnan(sigma(j))
            sigma(j) = 1;
        end
    end
end
T{:, featureVars} = bsxfun(@rdivide, bsxfun(@minus, T{:, featureVars}, mu), sigma);

[Xseq, Ytar, Yyear, Yid] = make_lstm_samples(T, featureVars, seqLen); %#ok<ASGLU>
if isempty(Xseq)
    error('No samples for model comparison. Check firm-year continuity.');
end

n = numel(Xseq);
numFeatures = numel(featureVars);
Xflat = nan(n, numFeatures * seqLen);
for i = 1:n
    Xi = Xseq{i};
    Xflat(i, :) = Xi(:)';
end

idxTrain = Yyear <= 2020;
idxVal = Yyear >= 2021 & Yyear <= 2022;
idxTest = Yyear >= 2023 & Yyear <= 2024;

XTrain = Xflat(idxTrain, :);
YTrain = Ytar(idxTrain);
XVal = Xflat(idxVal, :);
YVal = Ytar(idxVal);
XTest = Xflat(idxTest, :);
YTest = Ytar(idxTest);

Model = {};
MAE = [];
RMSE = [];
R2 = [];
Remark = {};

% --------------------------
% 1. BP neural network
% --------------------------
try
    XTrainVal = [XTrain; XVal];
    YTrainVal = [YTrain; YVal];

    net = fitnet(16, 'trainscg');
    net.trainParam.showWindow = false;
    net.trainParam.epochs = 300;
    net.trainParam.max_fail = 20;
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:size(XTrain, 1);
    net.divideParam.valInd = (size(XTrain, 1)+1):size(XTrainVal, 1);
    net.divideParam.testInd = [];

    net = train(net, XTrainVal', YTrainVal');
    yhat_bp = net(XTest')';
    [mae, rmse, r2] = calc_metrics(YTest, yhat_bp);
    Model{end+1,1} = 'BP neural network'; MAE(end+1,1) = mae; RMSE(end+1,1) = rmse; R2(end+1,1) = r2; Remark{end+1,1} = 'OK';
catch ME
    Model{end+1,1} = 'BP neural network'; MAE(end+1,1) = NaN; RMSE(end+1,1) = NaN; R2(end+1,1) = NaN; Remark{end+1,1} = ['Skipped: ', ME.message];
end

% --------------------------
% 2. Random Forest / Bagging regression
% --------------------------
try
    rf = TreeBagger(100, XTrain, YTrain, 'Method', 'regression', 'MinLeafSize', 5, 'OOBPrediction', 'off');
    yhat_rf = predict(rf, XTest);
    if iscell(yhat_rf)
        yhat_rf = str2double(yhat_rf);
    end
    [mae, rmse, r2] = calc_metrics(YTest, yhat_rf);
    Model{end+1,1} = 'Random Forest'; MAE(end+1,1) = mae; RMSE(end+1,1) = rmse; R2(end+1,1) = r2; Remark{end+1,1} = 'OK';
catch ME
    Model{end+1,1} = 'Random Forest'; MAE(end+1,1) = NaN; RMSE(end+1,1) = NaN; R2(end+1,1) = NaN; Remark{end+1,1} = ['Skipped: ', ME.message];
end

% --------------------------
% 3. Existing LSTM results
% --------------------------
lstmPredFile = fullfile(MATLAB_OUT, 'lstm_test_predictions.csv');
if exist(lstmPredFile, 'file') == 2
    L = readtable(lstmPredFile);
    if ismember('Eff_actual', L.Properties.VariableNames) && ismember('Eff_pred', L.Properties.VariableNames)
        L.Eff_actual = to_numeric_col(L.Eff_actual);
        L.Eff_pred = to_numeric_col(L.Eff_pred);
        [mae, rmse, r2] = calc_metrics(L.Eff_actual, L.Eff_pred);
        Model{end+1,1} = 'LSTM'; MAE(end+1,1) = mae; RMSE(end+1,1) = rmse; R2(end+1,1) = r2; Remark{end+1,1} = 'Existing LSTM output';
    else
        Model{end+1,1} = 'LSTM'; MAE(end+1,1) = NaN; RMSE(end+1,1) = NaN; R2(end+1,1) = NaN; Remark{end+1,1} = 'lstm_test_predictions.csv lacks Eff_actual or Eff_pred';
    end
else
    Model{end+1,1} = 'LSTM'; MAE(end+1,1) = NaN; RMSE(end+1,1) = NaN; R2(end+1,1) = NaN; Remark{end+1,1} = 'Please run m02_run_lstm.m first';
end

Result = table(Model, MAE, RMSE, R2, Remark);
writetable(Result, fullfile(TABLE, 'Table7_model_comparison_BP_RF_LSTM.xlsx'));
writetable(Result, fullfile(MATLAB_OUT, 'model_comparison_BP_RF_LSTM.csv'));

disp(Result);
fprintf('\nModel comparison is done. Output: %s\n', fullfile(TABLE, 'Table7_model_comparison_BP_RF_LSTM.xlsx'));
