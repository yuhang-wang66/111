function x = to_numeric_col(x)
% Convert a table column to double if needed.
if isnumeric(x)
    x = double(x);
elseif iscell(x)
    x = str2double(x);
else
    try
        x = str2double(cellstr(x));
    catch
        x = double(x);
    end
end
end
