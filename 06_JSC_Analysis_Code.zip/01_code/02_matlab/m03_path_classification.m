clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm00_paths.m'));

deaFile = fullfile(MATLAB_OUT, 'dea_results.csv');
futureFile = fullfile(MATLAB_OUT, 'lstm_future_2025.csv');

if exist(deaFile, 'file') ~= 2
    error('Cannot find DEA result file: %s', deaFile);
end
if exist(futureFile, 'file') ~= 2
    error('Cannot find LSTM future forecast file: %s. Please run m02_run_lstm.m first.', futureFile);
end

T = readtable(deaFile);
F = readtable(futureFile);
T = normalize_stkcd_in_table(T);
F = normalize_stkcd_in_table(F);

T.year = to_numeric_col(T.year);
numVarsT = {'Eff','r_asset','r_employee','r_dti','r_revenue'};
for i = 1:numel(numVarsT)
    if ismember(numVarsT{i}, T.Properties.VariableNames)
        T.(numVarsT{i}) = to_numeric_col(T.(numVarsT{i}));
    end
end
numVarsF = {'CurrentYear','Eff_current','Eff_pred_next','ETI'};
for i = 1:numel(numVarsF)
    if ismember(numVarsF{i}, F.Properties.VariableNames)
        F.(numVarsF{i}) = to_numeric_col(F.(numVarsF{i}));
    end
end

currentYear = 2024;
Tcur = T(T.year == currentYear, :);

keepVars = {'Stkcd','ShortName','IndustryCode','IndustryName','PROVINCE','CITY', ...
    'Eff','r_asset','r_employee','r_dti','r_revenue'};
existing = keepVars(ismember(keepVars, Tcur.Properties.VariableNames));
Tcur = Tcur(:, existing);

J = innerjoin(Tcur, F, 'Keys', 'Stkcd');

if height(J) == 0
    error('No matched data between DEA current-year data and LSTM forecast data. Please check Stkcd format.');
end

e = J.Eff(~isnan(J.Eff));
medEff = median(e);

J.CurrentLevel = repmat({''}, height(J), 1);
idxHigh = J.Eff >= medEff;
J.CurrentLevel(idxHigh) = repmat({'High efficiency'}, sum(idxHigh), 1);
J.CurrentLevel(~idxHigh) = repmat({'Low efficiency'}, sum(~idxHigh), 1);

J.Trend = repmat({''}, height(J), 1);
idxUp = J.ETI >= 0;
J.Trend(idxUp) = repmat({'Improving or stable'}, sum(idxUp), 1);
J.Trend(~idxUp) = repmat({'Warning decline'}, sum(~idxUp), 1);

J.Type = repmat({''}, height(J), 1);
for i = 1:height(J)
    if J.Eff(i) >= medEff && J.ETI(i) >= 0
        J.Type{i} = 'High-stable';
    elseif J.Eff(i) >= medEff && J.ETI(i) < 0
        J.Type{i} = 'High-warning';
    elseif J.Eff(i) < medEff && J.ETI(i) >= 0
        J.Type{i} = 'Low-improving';
    else
        J.Type{i} = 'Low-lagging';
    end
end

slackVars = {'r_asset','r_employee','r_dti','r_revenue'};
diagNames = {'Capital input redundancy', 'Labor input redundancy', 'Digital output insufficiency', 'Operating output insufficiency'};

R = nan(height(J), 4);
for j = 1:4
    if ismember(slackVars{j}, J.Properties.VariableNames)
        R(:, j) = J.(slackVars{j});
    end
end

J.MainDiagnosis = repmat({''}, height(J), 1);
J.MaxSlackRatio = nan(height(J), 1);

for i = 1:height(J)
    row = R(i, :);
    if all(isnan(row))
        J.MainDiagnosis{i} = 'No obvious slack';
        J.MaxSlackRatio(i) = NaN;
    else
        row2 = row;
        row2(isnan(row2)) = -Inf;
        [val, idx] = max(row2);
        J.MainDiagnosis{i} = diagNames{idx};
        J.MaxSlackRatio(i) = val;
    end
end

J.PathSuggestion = repmat({''}, height(J), 1);
for i = 1:height(J)
    if strcmp(J.MainDiagnosis{i}, 'Capital input redundancy')
        J.PathSuggestion{i} = 'Reduce repeated system construction; promote platform sharing and asset-light digitalization';
    elseif strcmp(J.MainDiagnosis{i}, 'Labor input redundancy')
        J.PathSuggestion{i} = 'Promote process automation, intelligent customer service, and digital-skill training';
    elseif strcmp(J.MainDiagnosis{i}, 'Digital output insufficiency')
        J.PathSuggestion{i} = 'Build data platforms, customer management systems, and online service channels';
    elseif strcmp(J.MainDiagnosis{i}, 'Operating output insufficiency')
        J.PathSuggestion{i} = 'Strengthen digital marketing, membership operation, and service product redesign';
    else
        J.PathSuggestion{i} = 'Maintain current resource allocation and continue monitoring efficiency trends';
    end
end

J.TypeSuggestion = repmat({''}, height(J), 1);
for i = 1:height(J)
    if strcmp(J.Type{i}, 'High-stable')
        J.TypeSuggestion{i} = 'Promote platform expansion, data asset accumulation, and ecosystem collaboration';
    elseif strcmp(J.Type{i}, 'High-warning')
        J.TypeSuggestion{i} = 'Control expansion of digital investment and optimize data governance and business processes';
    elseif strcmp(J.Type{i}, 'Low-improving')
        J.TypeSuggestion{i} = 'Continue strengthening digital tool application and address output bottlenecks';
    elseif strcmp(J.Type{i}, 'Low-lagging')
        J.TypeSuggestion{i} = 'Control inefficient input and prioritize low-cost modular process digitalization';
    end
end

outCsv = fullfile(MATLAB_OUT, 'path_classification_2024.csv');
outXlsx = fullfile(TABLE, 'path_classification_2024.xlsx');
writetable(J, outCsv);
writetable(J, outXlsx);

types = unique(J.Type);
N = zeros(numel(types), 1);
for i = 1:numel(types)
    N(i) = sum(strcmp(J.Type, types{i}));
end
typeTbl = table(types, N, N ./ sum(N), 'VariableNames', {'Type','N','Ratio'});
writetable(typeTbl, fullfile(TABLE, 'type_count_2024.xlsx'));

f = figure('Visible', 'off');
scatter(J.Eff, J.ETI, 20, 'filled');
hold on;
yl = ylim;
line([medEff medEff], yl, 'LineStyle', '--');
xl = xlim;
line(xl, [0 0], 'LineStyle', '--');
xlabel('Current DEA efficiency');
ylabel('Efficiency trend warning index ETI');
title('Current Efficiency and Future Trend Matrix');
grid on;
saveas(f, fullfile(FIG, 'efficiency_trend_matrix.png'));
close(f);

fprintf('Path classification completed: %s\n', outCsv);
