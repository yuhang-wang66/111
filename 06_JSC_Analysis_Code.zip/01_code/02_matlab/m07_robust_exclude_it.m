clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm00_paths.m'));

infile = fullfile(MATLAB_IN, 'panel_dea_lstm.csv');
if exist(infile, 'file') ~= 2
    error('Cannot find input file: %s. Please run Stata 10_prepare_panel.do first.', infile);
end

T = readtable(infile);
T = normalize_stkcd_in_table(T);

required = {'year','Asset_100m','Employee','DTI_pos','Revenue_100m','IndustryCode'};
for i = 1:numel(required)
    if ~ismember(required{i}, T.Properties.VariableNames)
        error('Missing variable: %s.', required{i});
    end
end
numVars = {'year','Asset_100m','Employee','DTI_pos','Revenue_100m'};
for i = 1:numel(numVars)
    T.(numVars{i}) = to_numeric_col(T.(numVars{i}));
end

% Exclude information transmission, software, and IT services: IndustryCode starts with I.
if iscell(T.IndustryCode)
    ind = T.IndustryCode;
else
    ind = cellstr(string(T.IndustryCode));
end
isIT = false(height(T), 1);
for i = 1:height(T)
    if ~isempty(ind{i})
        isIT(i) = strncmp(strtrim(ind{i}), 'I', 1);
    end
end
T = T(~isIT, :);

T.Eff_noIT = nan(height(T), 1);
T.slack_asset_noIT = nan(height(T), 1);
T.slack_employee_noIT = nan(height(T), 1);
T.slack_dti_noIT = nan(height(T), 1);
T.slack_revenue_noIT = nan(height(T), 1);

years = unique(T.year);
years = sort(years(~isnan(years)));

for k = 1:length(years)
    y = years(k);
    valid = T.year == y & ...
        ~isnan(T.Asset_100m) & ~isnan(T.Employee) & ~isnan(T.DTI_pos) & ~isnan(T.Revenue_100m) & ...
        T.Asset_100m > 0 & T.Employee > 0 & T.DTI_pos > 0 & T.Revenue_100m > 0;

    rows = find(valid);
    fprintf('\nExclude-IT robustness, Year %d: DMUs = %d\n', y, numel(rows));
    if numel(rows) < 10
        warning('Year %d has fewer than 10 DMUs; skipped.', y);
        continue;
    end

    X = [T.Asset_100m(rows), T.Employee(rows)];
    Y = [T.DTI_pos(rows), T.Revenue_100m(rows)];

    [eff, sx, sy] = sbm_vrs(X, Y);
    T.Eff_noIT(rows) = eff;
    T.slack_asset_noIT(rows) = sx(:, 1);
    T.slack_employee_noIT(rows) = sx(:, 2);
    T.slack_dti_noIT(rows) = sy(:, 1);
    T.slack_revenue_noIT(rows) = sy(:, 2);
end

T.r_asset_noIT = T.slack_asset_noIT ./ T.Asset_100m;
T.r_employee_noIT = T.slack_employee_noIT ./ T.Employee;
T.r_dti_noIT = T.slack_dti_noIT ./ T.DTI_pos;
T.r_revenue_noIT = T.slack_revenue_noIT ./ T.Revenue_100m;

writetable(T, fullfile(MATLAB_OUT, 'robust_exclude_IT_results.csv'));

S_year = unique(T.year(~isnan(T.year)));
N = zeros(numel(S_year),1); MeanEff = nan(numel(S_year),1); MedianEff = nan(numel(S_year),1); EfficientRatio = nan(numel(S_year),1);
for i = 1:numel(S_year)
    yy = S_year(i);
    v = T.Eff_noIT(T.year == yy & ~isnan(T.Eff_noIT));
    N(i) = numel(v);
    if ~isempty(v)
        MeanEff(i) = mean(v);
        MedianEff(i) = median(v);
        EfficientRatio(i) = mean(v >= 0.999999);
    end
end
NoITYearSummary = table(S_year, N, MeanEff, MedianEff, EfficientRatio, ...
    'VariableNames', {'year','N','MeanEff_noIT','MedianEff_noIT','EfficientRatio_noIT'});
writetable(NoITYearSummary, fullfile(TABLE, 'Robustness2_exclude_IT_year_summary.xlsx'));

fprintf('\nExclude-IT robustness is done. Outputs are in %s and %s\n', MATLAB_OUT, TABLE);
