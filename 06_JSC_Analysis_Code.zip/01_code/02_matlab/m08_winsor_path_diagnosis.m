clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm00_paths.m'));

pathFile = fullfile(MATLAB_OUT, 'path_classification_2024.csv');
if exist(pathFile, 'file') ~= 2
    error('Cannot find path classification file: %s. Please run m03_path_classification.m first.', pathFile);
end

T = readtable(pathFile);
T = normalize_stkcd_in_table(T);

ratioVars = {'r_asset','r_employee','r_dti','r_revenue'};
for i = 1:numel(ratioVars)
    if ~ismember(ratioVars{i}, T.Properties.VariableNames)
        error('Missing variable: %s.', ratioVars{i});
    end
    T.(ratioVars{i}) = to_numeric_col(T.(ratioVars{i}));
    T.([ratioVars{i}, '_w']) = winsor_vec(T.(ratioVars{i}), 1, 99);
end

R = [T.r_asset_w, T.r_employee_w, T.r_dti_w, T.r_revenue_w];
[maxv, idx] = max(R, [], 2);

labels = {'Capital input redundancy', ...
          'Labor input redundancy', ...
          'Digital output insufficiency', ...
          'Revenue output insufficiency'};
paths = {'Reduce repeated system construction and promote platform sharing and asset-light transformation', ...
         'Promote process automation, intelligent customer service, and digital skill training', ...
         'Build data platforms, customer management systems, and online service channels', ...
         'Strengthen digital marketing, membership operation, and service product redesign'};

T.MainDiagnosis_w = repmat({''}, height(T), 1);
T.PathSuggestion_w = repmat({''}, height(T), 1);
for i = 1:height(T)
    if isnan(maxv(i))
        T.MainDiagnosis_w{i} = 'Missing';
        T.PathSuggestion_w{i} = 'Missing';
    else
        T.MainDiagnosis_w{i} = labels{idx(i)};
        T.PathSuggestion_w{i} = paths{idx(i)};
    end
end
T.MaxSlackRatio_w = maxv;

writetable(T, fullfile(MATLAB_OUT, 'path_classification_2024_winsor.csv'));

% Type summary.
types = unique(T.Type);
N = zeros(numel(types), 1); MeanEff = nan(numel(types),1); MeanETI = nan(numel(types),1);
for i = 1:numel(types)
    if iscell(types)
        id = strcmp(T.Type, types{i});
        TypeName{i,1} = types{i}; %#ok<SAGROW>
    else
        id = T.Type == types(i);
        TypeName{i,1} = char(types(i)); %#ok<SAGROW>
    end
    N(i) = sum(id);
    if ismember('Eff_current', T.Properties.VariableNames)
        T.Eff_current = to_numeric_col(T.Eff_current);
        MeanEff(i) = mean(T.Eff_current(id), 'omitnan');
    end
    if ismember('ETI', T.Properties.VariableNames)
        T.ETI = to_numeric_col(T.ETI);
        MeanETI(i) = mean(T.ETI(id), 'omitnan');
    end
end
TypeSummary = table(TypeName, N, MeanEff, MeanETI);
writetable(TypeSummary, fullfile(TABLE, 'Table8_path_type_summary_winsor.xlsx'));

% Diagnosis summary after winsorization.
diags = unique(T.MainDiagnosis_w);
N = zeros(numel(diags), 1); MeanSlackRatio = nan(numel(diags), 1);
for i = 1:numel(diags)
    if iscell(diags)
        id = strcmp(T.MainDiagnosis_w, diags{i});
        Diagnosis{i,1} = diags{i}; %#ok<SAGROW>
    else
        id = T.MainDiagnosis_w == diags(i);
        Diagnosis{i,1} = char(diags(i)); %#ok<SAGROW>
    end
    N(i) = sum(id);
    MeanSlackRatio(i) = mean(T.MaxSlackRatio_w(id), 'omitnan');
end
DiagnosisSummary = table(Diagnosis, N, MeanSlackRatio);
writetable(DiagnosisSummary, fullfile(TABLE, 'Table9_diagnosis_summary_winsor.xlsx'));

fprintf('\nWinsorized path diagnosis is done. Output: %s\n', fullfile(MATLAB_OUT, 'path_classification_2024_winsor.csv'));
