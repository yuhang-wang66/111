clear; clc;
run(fullfile(fileparts(mfilename('fullpath')), 'm01_run_sbm_dea.m'));
run(fullfile(fileparts(mfilename('fullpath')), 'm02_run_lstm.m'));
run(fullfile(fileparts(mfilename('fullpath')), 'm03_path_classification.m'));
