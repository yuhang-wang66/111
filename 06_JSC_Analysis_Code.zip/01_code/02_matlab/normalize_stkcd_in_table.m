function T = normalize_stkcd_in_table(T)
% Make Stkcd a 6-digit cellstr key.
if ~ismember('Stkcd', T.Properties.VariableNames)
    return;
end
v = T.Stkcd;
if isnumeric(v)
    c = cell(size(v));
    for i = 1:numel(v)
        if isnan(v(i))
            c{i} = '';
        else
            c{i} = sprintf('%06.0f', v(i));
        end
    end
elseif iscell(v)
    c = cell(size(v));
    for i = 1:numel(v)
        if isnumeric(v{i})
            c{i} = sprintf('%06.0f', v{i});
        else
            tmp = strtrim(char(v{i}));
            if length(tmp) < 6 && all(tmp >= '0' & tmp <= '9')
                tmp = sprintf('%06.0f', str2double(tmp));
            end
            c{i} = tmp;
        end
    end
else
    try
        c = cellstr(v);
    catch
        c = cellstr(num2str(v));
    end
    for i = 1:numel(c)
        tmp = strtrim(c{i});
        if length(tmp) < 6 && all(tmp >= '0' & tmp <= '9')
            tmp = sprintf('%06.0f', str2double(tmp));
        end
        c{i} = tmp;
    end
end
T.Stkcd = c;
end
