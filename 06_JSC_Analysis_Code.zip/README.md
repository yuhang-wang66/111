# Digital transformation efficiency: source code

This repository contains Stata and MATLAB programs used for the analysis of Chinese listed service firms (2013–2024).

## Software

- Stata 17 or newer
- MATLAB with Optimization Toolbox, Deep Learning Toolbox, and Statistics and Machine Learning Toolbox

## Required inputs

The scripts expect firm identifiers, financial variables, employee counts, and digital transformation measurements in the source files specified in `10_prepare_panel.do`. Source data obtained under third-party database licenses are not included.

## Directory layout

- `01_code/01_stata/`: preparation of the firm-year panel and descriptive tables
- `01_code/02_matlab/`: annual SBM-DEA, forecasting, classifications, sensitivity analyses, and figures
- `00_raw_data/`: locally stored licensed input data (not distributed)
- `02_work_data/`: locally generated intermediate data
- `03_results/`: locally generated tables, figures, and logs

## Running the analysis

Open Stata in the repository root, then run:

```stata
do "01_code/01_stata/10_prepare_panel.do"
```

After the input panel has been exported to `02_work_data/02_matlab_input/panel_dea_lstm.csv`, run in MATLAB:

```matlab
run('01_code/02_matlab/m99_run_all_matlab.m')
run('01_code/02_matlab/m99_run_required_addons.m')
```

Then return to Stata to generate the additional descriptive tables:

```stata
do "01_code/01_stata/20_required_tables.do"
```

## Data use

The source datasets are subject to their providers' access and redistribution rules. Set the current working directory to the repository root and place authorized input files under `00_raw_data/` before running the scripts. Code and licensed records are distributed separately.
